import express from "express";
import addUser, { sendData } from "../Controller/userController.js";

const user = express.Router();

user.post("/addUser", addUser);
user.post("/sendData",sendData)

export default user;
