import Admin from "../Schema/adminSchema.js";
import User from "../Schema/userSchema.js";
import nodemailer from "nodemailer";
import axios from "axios";
import locationLive from "../Schema/locationLive.js";
import NodeGeocoder from "node-geocoder";
import twilio from "twilio";


const addUser = async (req, res, next) => {
    const { name, email, mobileno, locationDefault } = req.body; // Corrected `loactionDefault` typo
    try {
        if (!name || !email || !mobileno || !locationDefault) {
            return res.status(400).json({
                success: false,
                message: "All fields are required",
            });
        }

        if (mobileno.length !== 10) { // Validate mobile number length
            return res.status(400).json({
                success: false,
                message: "Mobile number must be exactly 10 digits",
            });
        }

        const user = await User.create({ name, email, mobileno, locationDefault });
        res.status(201).json({
            success: true,
            message: "Registration successful",
            user,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

export default addUser;


const accountSid = "ACc1ff0737cbdcb5c5d1c5d78b81afa1ee"; // Replace with your Account SID
const authToken = "412ee783f827a29ccf593e28a45fdfe8"; // Replace with your Auth Token
const fromPhoneNumber = "+16282144065";

export const sendData = async (req, res) => {
    const { name, email, mobileno, latitude, longitude } = req.body;

    try {
        if (!name || !email || !mobileno || !latitude || !longitude) {
            return res.status(400).json({
                success: false,
                message: "Name, email, mobile number, latitude, and longitude are required",
            });
        }

        const user = await User.findOne({ name, email, mobileno });
        if (!user) {
            return res.status(404).json({ success: false, message: "User not found" });
        }

        let address = "Unknown Address";
        let city = "Unknown City";
        let state = "Unknown State";
        let country = "Unknown Country";
        let postalCode = "Unknown Postal Code";

        try {
            const response = await axios.get(
                `https://api.opencagedata.com/geocode/v1/json`,
                {
                    params: {
                        q: `${latitude},${longitude}`,
                        key: "6e6fa24c73f941fd9e45c9afb3b1a145",
                    },
                }
            );
            if (response.data?.results?.length > 0) {
                const result = response.data.results[0];
                const components = result.components;

                address = result.formatted || "Unknown Address";
                city = components.city || components.town || components.village || "Unknown City";
                state = components.state || "Unknown State";
                country = components.country || "Unknown Country";
                postalCode = components.postcode || "Unknown Postal Code";
            }
        } catch (error) {
            console.error("Reverse Geocoding Error:", error.message);
        }

        const location = new locationLive({
            userId: user._id,
            latitude,
            longitude,
            address,
            city,
            state,
            country,
            postalCode,
            timestamp: new Date(),
        });
        await location.save();

        const admins = await Admin.find();
        if (!admins || admins.length === 0) {
            return res.status(404).json({ success: false, message: "No admin details found" });
        }

        const client = twilio(accountSid, authToken);
        const smsContent = `User Details:\nName: ${user.name}\nEmail: ${user.email}\nMobile No: ${user.mobileno}\nLive Location:\nLatitude: ${latitude}\nLongitude: ${longitude}\nAddress: ${address}\nCity: ${city}\nState: ${state}\nCountry: ${country}\nPostal Code: ${postalCode}`;
        
        for (const admin of admins) {
            try {
                let mobileNo = admin.mobileNo;
        
                // Ensure phone number is in E.164 format (add country code if missing)
                if (!mobileNo.startsWith("+")) {
                    mobileNo = `+91${mobileNo.trim()}`; // Default to +91 for India (replace with your country code)
                }
        
                // Validate the number using a regular expression
                const isValidNumber = /^\+\d{10,15}$/.test(mobileNo);
                if (!isValidNumber) {
                    console.error(`Invalid Phone Number Format: ${mobileNo}`);
                    continue; // Skip invalid numbers
                }
        
                // Send SMS using Twilio
                await client.messages.create({
                    body: smsContent,
                    from: fromPhoneNumber,
                    to: mobileNo,
                });
        
                console.log(`SMS Sent Successfully to ${mobileNo}`);
            } catch (error) {
                console.error(`Error Sending SMS to ${admin.mobileno}:`, error.message);
            }
        }
        

        const transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: "helpwomenacccc@gmail.com",
                pass: "ofgd wwdl kqtj diea",
            },
            tls: { rejectUnauthorized: false },
        });

        for (const admin of admins) {
            try {
                await transporter.sendMail({
                    from: "helpwomenacccc@gmail.com",
                    to: admin.email,
                    subject: "User Details and Live Location",
                    text: smsContent,
                });
            } catch (error) {
                console.error(`Error Sending Email to ${admin.email}:`, error.message);
            }
        }

        return res.status(200).json({
            success: true,
            message: "User data and live location sent to admins successfully via email and SMS!",
            data: {
                name: user.name,
                email: user.email,
                mobileno: user.mobileno,
                location: {
                    latitude,
                    longitude,
                    address,
                    timestamp: location.timestamp,
                },
            },
        });
    } catch (error) {
        console.error("Error in sendData:", error);
        res.status(500).json({
            success: false,
            message: "Internal Server Error",
            error: error.message,
        });
    }
};
